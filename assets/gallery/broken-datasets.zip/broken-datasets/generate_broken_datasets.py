#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 31 13:11:49 2023

@author: alin62
"""
import numpy as np
from matplotlib import pyplot as plt
from scipy.spatial.transform import Rotation as R
from ase.io import write
from ase import Atoms

# Small functions for rotating matrices
def rot_x(A, angle):
    return A @ np.array(
        [
            [1.0, 0.0, 0.0],
            [0, np.cos(angle), -np.sin(angle)],
            [0, np.sin(angle), np.cos(angle)]
        ]
    )

def rot_y(A, angle):
    return A @ np.array(
        [
            [np.cos(angle), 0.0, np.sin(angle)],
            [0.0, 1.0, 0.0],
            [-np.sin(angle), 0.0, np.cos(angle)],
        ]
    )


def rot_z(A, angle):
    return A @ np.array(
        [
            [np.cos(angle), -np.sin(angle), 0.0],
            [np.sin(angle), np.cos(angle), 0.0],
            [0.0, 0.0, 1.0],
        ]
    )

# Gay-Berne Potential, as defined by Everaers and Ejtehadi
# This has the r12_hat correction.
def gay_berne(
    A1, A2, S1, S2, r12, e, sigma=None, nu=1.0, mu=1.0, gamma=1.0, eps_GB=1.0
):
    if sigma is None:
        sigma = np.min([np.diag(S1).min(), np.diag(S2).min()])

    def G1(A, S):
        return A.T @ S**2.0 @ A

    def B(A, E):
        return A.T @ E @ A

    def s(S):
        a, b, c = np.diag(S)
        return (a * b + c * c) * (a * b) ** (0.5)
    
    r12_hat = r12/np.linalg.norm(r12)
    G12 = G1(A1, S1) + G1(A2, S2)
    sigma_12 = (0.5 * r12_hat.T @ np.linalg.pinv(G12) @ r12_hat) ** (-0.5)
    h12 = np.linalg.norm(r12) - sigma_12

    rho = sigma / (h12 + gamma * sigma)
    Ur = 4 * eps_GB * ((rho) ** 12.0 - rho**6.0)

    E = np.diagflat(e ** (-1 / mu))
    B12 = B(A1, E) + B(A2, E)
    chi_12 = (2 * r12_hat.T @ np.linalg.pinv(B12) @ r12_hat) ** mu

    s1 = s(S1)
    s2 = s(S2)
    eta_12 = ((2 * s1 * s2) / np.linalg.det(G12)) ** (nu / 2.0)
    return Ur * eta_12 * chi_12


def verbose_write(filename, frames):
    print("Writing {} frames to {}.".format(len(frames), filename))
    write(filename, frames)

def generate_frame(r12, A1, A2, energy) -> Atoms:
    rx, ry, rz = r12
    frame = Atoms(
        cell=L * np.ones(3),
        positions=[[L / 2, L / 2, L / 2], [L / 2 + rx, L / 2 + ry, L / 2 + rz]],
        numbers=np.zeros(2),
    )

    raw_quaternions = np.array(
        [
            R.from_matrix(A1).as_quat(),
            R.from_matrix(A2).as_quat(),
        ]
    )
    quaternions = np.zeros(raw_quaternions.shape)
    quaternions[:, 0] = raw_quaternions[:, -1]
    quaternions[:, 1:] = raw_quaternions[:, :-1]
    frame.arrays["quaternions"] = quaternions
    frame.arrays["c_diameter\[1\]"] = a0 * np.ones(len(frame))
    frame.arrays["c_diameter\[2\]"] = b0 * np.ones(len(frame))
    frame.arrays["c_diameter\[3\]"] = c0 * np.ones(len(frame))

    frame.info["energy"] = energy
    return frame
    

a0 = b0 = 1.0
c0 = 2.0
S0 = np.diagflat([a0, b0, c0])

sigma0 = min(a0, b0, c0)

e_a0 = sigma0 * (a0 / (b0 * c0))
e_b0 = sigma0 * (b0 / (a0 * c0))
e_c0 = sigma0 * (c0 / (b0 * a0))
e0 = np.array([e_a0, e_b0, e_c0])

A0 = np.eye(3)

L = 20
ry = 0
rz = 0

# ## Random Rotations and Distances
frames = []
for _ in range(1000):
    r12 = np.random.uniform(sigma0, 2*sigma0, size=3)
    A1 = R.random().as_matrix()
    A2 = R.random().as_matrix()
    energy = gay_berne(A1, A2, S0, S0, r12, e0, sigma0)
    frame = generate_frame(r12, A1, A2, energy)
    if frame.info["energy"] < 20:
        frames.append(frame)

verbose_write("random_rotations.xyz", frames)

# Single rotating in y
frames = []
rx = ry = rz = 0
r0_ss = 2.01010101010101
for rx in np.linspace(r0_ss, 3 * r0_ss, 10):
    for angle in np.linspace(0, np.pi/2, 10):
        A2 = rot_y(A0, angle)
        r12 = np.array([rx, ry, rz])
        energy = gay_berne(A0, A2, S0, S0, r12, e0, sigma0)
        frame = generate_frame(r12, A0, A2, energy)
        if frame.info["energy"] < 20:
            frames.append(frame)

# plt.plot([f.info['energy'] for f in frames])
verbose_write("single_rotating_in_y.xyz", frames)

# Single rotating in z
frames = []
rx = ry = rz = 0
r0_ss = 2.01010101010101
for rx in np.linspace(r0_ss, 3 * r0_ss, 10):
    for angle in np.linspace(0, np.pi, 10):
        A2 = rot_z(A0, angle)
        r12 = np.array([rx, ry, rz])
        energy = gay_berne(A0, A2, S0, S0, r12, e0, sigma0)
        frame = generate_frame(r12, A0, A2, energy)
        if frame.info["energy"] < 20:
            frames.append(frame)

plt.plot([f.info['energy'] for f in frames])
verbose_write("single_rotating_in_z.xyz", frames)

# Simple Rotations
# CANNOT REPORDUCE MY BROKEN DATASET :(
frames = []
rx=ry=rz=0
for rx in np.linspace(2,3,10):
    for _ in range(10):
        r12 = np.array([rx, ry, rz])
        phi1 = np.random.uniform(0, np.pi/3)
        phi2 = np.random.uniform(0, np.pi/2)
        A1 = rot_y(rot_z(A0, phi1), phi2)
        energy = gay_berne(A0, A1, S0, S0, r12, e0, sigma0)
        frame = generate_frame(r12, A0, A1, energy)
        if frame.info["energy"] < 20:
            frames.append(frame)
plt.plot([f.info['energy'] for f in frames])
verbose_write("simple_rotation2.xyz", frames)

        
